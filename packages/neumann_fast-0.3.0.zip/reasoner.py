# Vector-matrix forward reasoner
