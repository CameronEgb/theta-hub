"""Neumann fast reasoner."""
