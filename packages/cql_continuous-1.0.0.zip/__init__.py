"""Continuous CQL agent module."""
