"""WandB plugin scaffold."""
