"""Antigravity Panel widget for chat interface using google.antigravity SDK."""
from __future__ import annotations
import asyncio
from typing import TYPE_CHECKING, Optional

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, 
    QTextBrowser, QVBoxLayout, QWidget,
)

if TYPE_CHECKING:
    from frontend.plugins.context import PluginContext

# We use the official python SDK to connect to the Antigravity agent!
from google.antigravity import Agent, LocalAgentConfig, CapabilitiesConfig

class AgentWorker(QThread):
    response_chunk = pyqtSignal(str)
    response_complete = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self, prompt: str):
        super().__init__()
        self.prompt = prompt

    def run(self):
        asyncio.run(self.run_agent())

    async def run_agent(self):
        try:
            config = LocalAgentConfig(
                system_instructions="You are an expert assistant for codebase navigation in Theta-IDE.",
                capabilities=CapabilitiesConfig()
            )
            async with Agent(config) as agent:
                response = await agent.chat(self.prompt)
                async for token in response:
                    self.response_chunk.emit(token)
            self.response_complete.emit()
        except Exception as e:
            self.error_occurred.emit(str(e))

class AntigravityPanel(QWidget):
    """Integrated Antigravity Agent chat interface."""

    def __init__(self, context: PluginContext, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.context = context
        self._build_ui()
        self.worker = None

    def _build_ui(self):
        """Construct the Antigravity chat panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # Header
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        eyebrow = QLabel("ANTIGRAVITY AGENT")
        eyebrow.setObjectName("eyebrow")
        eyebrow.setStyleSheet("font-size: 11px; font-weight: 700; letter-spacing: 1px; color: #83a598;")
        
        title_label = QLabel("Chat with AI")
        title_label.setStyleSheet("font-size: 14px; font-weight: 600;")
        title_box.addWidget(eyebrow)
        title_box.addWidget(title_label)
        header_layout.addLayout(title_box)
        header_layout.addStretch()
        
        clear_btn = QPushButton("Clear Chat")
        clear_btn.clicked.connect(self._clear_chat)
        header_layout.addWidget(clear_btn)
        
        layout.addLayout(header_layout)

        # Chat History
        self.chat_history = QTextBrowser()
        self.chat_history.setOpenExternalLinks(True)
        # Use simple standard styling matching Theta-IDE themes roughly
        self.chat_history.setStyleSheet("background-color: transparent; border: 1px solid #333; padding: 8px; border-radius: 6px;")
        self._append_system_message("Antigravity Agent initialized. How can I help you build today?")
        layout.addWidget(self.chat_history)

        # Input Area
        input_layout = QHBoxLayout()
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Ask Antigravity to write code, explain errors, or run tasks...")
        self.message_input.returnPressed.connect(self._send_message)
        input_layout.addWidget(self.message_input)

        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self._send_message)
        input_layout.addWidget(self.send_btn)

        layout.addLayout(input_layout)

    def _append_system_message(self, text: str):
        self.chat_history.append(f"<b>[System]</b> {text}")

    def _append_user_message(self, text: str):
        self.chat_history.append(f"<br/><b style='color: #4daafc;'>[User]</b> {text}")

    def _append_agent_message_start(self):
        self.chat_history.append(f"<br/><b style='color: #4caf50;'>[Antigravity]</b> ")
        # Ensure it moves to the end so we can append text cleanly
        self.chat_history.moveCursor(self.chat_history.textCursor().MoveOperation.End)

    def _append_agent_chunk(self, text: str):
        # insert plaintext at the end
        self.chat_history.insertPlainText(text)
        self.chat_history.moveCursor(self.chat_history.textCursor().MoveOperation.End)

    def _send_message(self):
        text = self.message_input.text().strip()
        if not text:
            return
            
        self.message_input.clear()
        self.message_input.setEnabled(False)
        self.send_btn.setEnabled(False)
        
        self._append_user_message(text)
        self._append_agent_message_start()
        
        self.worker = AgentWorker(text)
        self.worker.response_chunk.connect(self._append_agent_chunk)
        self.worker.response_complete.connect(self._on_agent_complete)
        self.worker.error_occurred.connect(self._on_agent_error)
        self.worker.start()

    def _on_agent_complete(self):
        self.message_input.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.message_input.setFocus()

    def _on_agent_error(self, err: str):
        self._append_system_message(f"Error: {err}")
        self.message_input.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.message_input.setFocus()

    def _clear_chat(self):
        self.chat_history.clear()
        self._append_system_message("Chat history cleared.")
