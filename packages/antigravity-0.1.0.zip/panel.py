"""Antigravity Panel widget for chat interface."""
from __future__ import annotations
from typing import TYPE_CHECKING, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, 
    QTextBrowser, QVBoxLayout, QWidget,
)

if TYPE_CHECKING:
    from frontend.plugins.context import PluginContext


class AntigravityPanel(QWidget):
    """Integrated Antigravity Agent chat interface."""

    def __init__(self, context: PluginContext, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.context = context
        self._build_ui()

    def _build_ui(self):
        """Construct the Antigravity chat panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel("Antigravity Agent")
        title_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        
        clear_btn = QPushButton("Clear Chat")
        clear_btn.clicked.connect(self._clear_chat)
        header_layout.addWidget(clear_btn)
        
        layout.addLayout(header_layout)

        # Chat History
        self.chat_history = QTextBrowser()
        self.chat_history.setOpenExternalLinks(True)
        self.chat_history.setStyleSheet("background-color: #1e1e1e; color: #d4d4d4; padding: 4px; border-radius: 4px;")
        self._append_system_message("Antigravity Agent initialized. How can I help you build today?")
        layout.addWidget(self.chat_history)

        # Input Area
        input_layout = QHBoxLayout()
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Ask Antigravity to write code, explain errors, or run tasks...")
        self.message_input.returnPressed.connect(self._send_message)
        input_layout.addWidget(self.message_input)

        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self._send_message)
        input_layout.addWidget(send_btn)

        layout.addLayout(input_layout)

    def _append_system_message(self, text: str):
        self.chat_history.append(f"<b>[System]</b> {text}")

    def _append_user_message(self, text: str):
        self.chat_history.append(f"<b style='color: #4daafc;'>[User]</b> {text}")

    def _append_agent_message(self, text: str):
        self.chat_history.append(f"<b style='color: #4caf50;'>[Antigravity]</b> {text}")

    def _send_message(self):
        text = self.message_input.text().strip()
        if not text:
            return
            
        self.message_input.clear()
        self._append_user_message(text)
        
        # Mock response from Antigravity
        self._append_agent_message("I am a mock Antigravity agent in ThetaIDE. I don't have real intelligence yet, but I can pretend to help you!")

    def _clear_chat(self):
        self.chat_history.clear()
        self._append_system_message("Chat history cleared.")
