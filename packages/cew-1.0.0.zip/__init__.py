"""CEW model module."""
